export let FrequencyEnum = /*#__PURE__*/ (function (FrequencyEnum) {
  FrequencyEnum["Yearly"] = "yearly";
  FrequencyEnum["Quarterly"] = "quarterly";

  return FrequencyEnum;
})({});

export let TiersEnum = /*#__PURE__*/ (function (TiersEnum) {
  TiersEnum["Free"] = "free";
  TiersEnum["Pro"] = "pro";
  TiersEnum["Team"] = "team";

  return TiersEnum;
})({});
